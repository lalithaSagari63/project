
prompt("COME ON BUDDY!! LET'S PLAY A GAME ..Just warm up ");
alert("Shall we play buddy?");

var  Name=prompt("what is your name?");
document.write("Hello "+Name+" you are ready ro start the game");
var answer=prompt("WHAT IS THE ANSWER FOR 5+4+7+9=");
if(answer===25)
{
	alert("right answer");
	document.write("ur score is +1");
}
if(answer!==25){
	document.write("the answer is 25 and ur score is 0");
	}
var answer1=prompt("WHAT IS THE ANSWER FOR 5*4/3+45=");
if(answer1===5.1666)
{
	alert("right answer");
    	alert("ur score is +1");	
}
if(answer1!==5.1666){
	document.write("the answer is 5.1666.and ur count is ");
	}




